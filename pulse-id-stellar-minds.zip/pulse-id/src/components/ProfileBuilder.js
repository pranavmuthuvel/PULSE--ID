// src/components/ProfileBuilder.js
import React, { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { saveProfile } from "../services/firebaseService";
import { transcribeAndExtract } from "../services/claudeService";
import { getAuth, signInAnonymously } from "firebase/auth";

const BLOOD_TYPES = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

export default function ProfileBuilder({ userId, lang, onSaved }) {
  const { t } = useTranslation();
  const [form, setForm] = useState({
    name: "", age: "", bloodType: "O+",
    allergies: "", conditions: "", medications: "", emergencyContact: ""
  });
  const [saving, setSaving] = useState(false);
  const [listening, setListening] = useState(false);
  const [success, setSuccess] = useState(false);
  const recognitionRef = useRef(null);

  const langCodeMap = { en: "en-IN", ta: "ta-IN", hi: "hi-IN", bn: "bn-IN" };

  const startVoice = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { alert("Voice not supported in this browser. Use Chrome."); return; }
    const rec = new SpeechRecognition();
    rec.lang = langCodeMap[lang] || "en-IN";
    rec.continuous = false;
    rec.interimResults = false;
    rec.onstart = () => setListening(true);
    rec.onend = () => setListening(false);
    rec.onresult = async (e) => {
      const spoken = e.results[0][0].transcript;
      const extracted = await transcribeAndExtract(spoken, lang);
      if (extracted) {
        setForm(prev => ({
          ...prev,
          ...Object.fromEntries(Object.entries(extracted).filter(([, v]) => v))
        }));
      }
    };
    rec.start();
    recognitionRef.current = rec;
  };

  const handleChange = (field, val) => setForm(prev => ({ ...prev, [field]: val }));

  const handleSave = async () => {
    if (!form.name || !form.bloodType) { alert("Name and blood type are required."); return; }
    setSaving(true);
    try {
      const auth = getAuth();
      let uid = userId;
      if (!uid) {
        const cred = await signInAnonymously(auth);
        uid = cred.user.uid;
      }
      await saveProfile(uid, form);
      setSuccess(true);
      setTimeout(() => onSaved(uid, form), 1200);
    } catch (e) {
      alert("Error saving profile: " + e.message);
    }
    setSaving(false);
  };

  return (
    <div>
      <button className="back-btn" onClick={() => window.history.back()}>← Back</button>

      <div className="card">
        <div className="card-title">Health Profile Setup</div>

        <div style={{ marginBottom: 20 }}>
          <button
            className={`btn-icon ${listening ? "listening" : ""}`}
            onClick={startVoice}
            style={{ width: "100%", justifyContent: "center" }}
          >
            🎤 {listening ? t("listening") : `${t("speak")} — Fill by Voice`}
          </button>
          <p style={{ fontSize: 11, color: "var(--muted)", textAlign: "center", marginTop: 8 }}>
            Speak your medical info — AI will auto-fill the form
          </p>
        </div>

        <div className="divider" />

        <div className="input-group">
          <label className="input-label">{t("name")} *</label>
          <input className="input-field" value={form.name} onChange={e => handleChange("name", e.target.value)} placeholder="Arjun Kumar" />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <div className="input-group">
            <label className="input-label">{t("age")}</label>
            <input className="input-field" type="number" value={form.age} onChange={e => handleChange("age", e.target.value)} placeholder="34" />
          </div>
          <div className="input-group">
            <label className="input-label">{t("bloodType")} *</label>
            <select className="input-field" value={form.bloodType} onChange={e => handleChange("bloodType", e.target.value)}>
              {BLOOD_TYPES.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>
        </div>

        <div className="input-group">
          <label className="input-label">⚠️ {t("allergies")}</label>
          <input className="input-field" value={form.allergies} onChange={e => handleChange("allergies", e.target.value)} placeholder="Penicillin, Aspirin, Peanuts" />
        </div>

        <div className="input-group">
          <label className="input-label">{t("conditions")}</label>
          <input className="input-field" value={form.conditions} onChange={e => handleChange("conditions", e.target.value)} placeholder="Asthma, Hypertension, Diabetes" />
        </div>

        <div className="input-group">
          <label className="input-label">{t("medications")}</label>
          <input className="input-field" value={form.medications} onChange={e => handleChange("medications", e.target.value)} placeholder="Salbutamol 100mcg, Amlodipine 5mg" />
        </div>

        <div className="input-group">
          <label className="input-label">{t("emergencyContact")}</label>
          <input className="input-field" value={form.emergencyContact} onChange={e => handleChange("emergencyContact", e.target.value)} placeholder="+91 98765 43210 — Father" />
        </div>

        {success && <div className="success-msg">✓ {t("profileSaved")}</div>}

        <button className="btn-primary" onClick={handleSave} disabled={saving}>
          {saving ? t("saving") : `💾 ${t("save")}`}
        </button>
      </div>
    </div>
  );
}
