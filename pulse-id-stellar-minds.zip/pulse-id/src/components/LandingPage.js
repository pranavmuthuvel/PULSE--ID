// src/components/LandingPage.js
import React from "react";
import { useTranslation } from "react-i18next";

export default function LandingPage({ userId, onCreateProfile, onMyQR, onScan, onDrugCheck }) {
  const { t } = useTranslation();

  return (
    <div>
      <div className="hero">
        <div className="emergency-badge">
          <span>🚨</span> AI Emergency Medical Identity
        </div>
        <h1 className="hero-title">
          PULSE<span>ID</span>
        </h1>
        <p className="hero-sub">
          Scan a QR. Save a life.<br />
          AI-powered emergency medical identity in Tamil, Hindi, Bengali & English.
        </p>
      </div>

      <div className="stat-row">
        <div className="stat-box">
          <div className="stat-num">4min</div>
          <div className="stat-label">ER death rate from unknown allergies</div>
        </div>
        <div className="stat-box">
          <div className="stat-num">250K</div>
          <div className="stat-label">Annual preventable medical errors India</div>
        </div>
        <div className="stat-box">
          <div className="stat-num">10sec</div>
          <div className="stat-label">PULSE ID emergency summary time</div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">For Patients</div>
        {!userId ? (
          <button className="btn-primary" onClick={onCreateProfile}>
            🏥 {t("createProfile")}
          </button>
        ) : (
          <div>
            <div className="success-msg">✓ Profile Active</div>
            <button className="btn-primary" onClick={onMyQR} style={{ marginBottom: 12 }}>
              📱 {t("myQR")}
            </button>
            <button className="btn-secondary" onClick={onCreateProfile}>
              ✏️ Update Profile
            </button>
          </div>
        )}
      </div>

      <div className="card">
        <div className="card-title">For Doctors / Paramedics</div>
        <div className="btn-grid">
          <button className="btn-secondary" onClick={onScan}>
            🔍 {t("scanQR")}
          </button>
          <button className="btn-secondary" onClick={onDrugCheck}>
            💊 {t("drugCheck")}
          </button>
        </div>
      </div>

      <div className="card">
        <div className="card-title">How It Works</div>
        {[
          ["1", "Patient creates profile in their language via voice or text"],
          ["2", "Unique QR code generated — keep it on your phone or wristband"],
          ["3", "Doctor scans QR — AI emergency summary appears in 10 seconds"],
          ["4", "Drug interaction detection before prescribing any medication"],
          ["5", "Full records unlocked only with patient OTP — privacy secured"],
        ].map(([n, text]) => (
          <div key={n} style={{ display: "flex", gap: 14, marginBottom: 14, alignItems: "flex-start" }}>
            <div style={{
              minWidth: 28, height: 28, borderRadius: "50%",
              background: "var(--red)", display: "flex", alignItems: "center",
              justifyContent: "center", fontSize: 12, fontWeight: 800,
              fontFamily: "var(--font-display)"
            }}>{n}</div>
            <p style={{ fontSize: 14, lineHeight: 1.5, color: "var(--white)", paddingTop: 4 }}>{text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
