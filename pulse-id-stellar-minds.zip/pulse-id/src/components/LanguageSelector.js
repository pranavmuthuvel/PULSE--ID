// src/components/LanguageSelector.js
import React from "react";

const LANGS = [
  { code: "en", label: "EN 🇬🇧" },
  { code: "ta", label: "தமிழ்" },
  { code: "hi", label: "हिंदी" },
  { code: "bn", label: "বাংলা" },
];

export default function LanguageSelector({ lang, onChange }) {
  return (
    <select className="lang-select" value={lang} onChange={e => onChange(e.target.value)}>
      {LANGS.map(l => (
        <option key={l.code} value={l.code}>{l.label}</option>
      ))}
    </select>
  );
}
