// src/components/EmergencyScan.js
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { getProfileById, logEmergencyAccess, generateOTP } from "../services/firebaseService";
import { generateEmergencySummary } from "../services/claudeService";

export default function EmergencyScan({ userId, lang, onBack }) {
  const { t } = useTranslation();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [aiSummary, setAiSummary] = useState("");
  const [generatingAI, setGeneratingAI] = useState(false);
  const [showFull, setShowFull] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpInput, setOtpInput] = useState("");
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [manualId, setManualId] = useState("");

  useEffect(() => {
    if (userId) loadProfile(userId);
    else setLoading(false);
  }, [userId]);

  const loadProfile = async (id) => {
    setLoading(true);
    try {
      const data = await getProfileById(id);
      if (data) {
        setProfile(data);
        await logEmergencyAccess(id, "emergency_view");
        generateSummary(data);
      }
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const generateSummary = async (p) => {
    setGeneratingAI(true);
    try {
      const summary = await generateEmergencySummary(p, lang);
      setAiSummary(summary);
    } catch (e) { setAiSummary("Error generating summary. Check API key."); }
    setGeneratingAI(false);
  };

  const handleSendOTP = () => {
    const newOtp = generateOTP();
    setOtp(newOtp);
    setOtpSent(true);
    // In production: send via Firebase Phone Auth
    // For demo: show OTP in alert
    alert(`Demo OTP (would be sent via SMS): ${newOtp}`);
  };

  const handleVerifyOTP = () => {
    if (otpInput === otp) {
      setShowFull(true);
      setOtpError("");
    } else {
      setOtpError("Incorrect OTP. Try again.");
    }
  };

  if (loading) return (
    <div className="loading-spinner">
      <div className="spinner" />
      Loading patient profile...
    </div>
  );

  if (!userId && !profile) return (
    <div>
      <button className="back-btn" onClick={onBack}>← Back</button>
      <div className="card">
        <div className="card-title">Scan or Enter Patient ID</div>
        <p style={{ fontSize: 14, color: "var(--muted)", marginBottom: 16 }}>
          Use your phone camera to scan patient QR, or enter their PULSE ID manually.
        </p>
        <div className="input-group">
          <label className="input-label">Patient PULSE ID</label>
          <input className="input-field" value={manualId} onChange={e => setManualId(e.target.value)} placeholder="Enter patient ID..." />
        </div>
        <button className="btn-primary" onClick={() => loadProfile(manualId)} disabled={!manualId}>
          🔍 Load Emergency Summary
        </button>
      </div>
    </div>
  );

  if (!profile) return (
    <div>
      <button className="back-btn" onClick={onBack}>← Back</button>
      <div className="card">
        <div className="alert alert-amber">
          <div className="alert-title">⚠️ Profile Not Found</div>
          <p>{t("noProfile")}</p>
        </div>
      </div>
    </div>
  );

  const allergies = profile.allergies?.split(",").map(a => a.trim()).filter(Boolean) || [];

  return (
    <div>
      <button className="back-btn" onClick={onBack}>← Back</button>

      {/* Emergency Header */}
      <div className="emergency-badge" style={{ width: "100%", justifyContent: "center", borderRadius: 14, padding: "12px 20px" }}>
        🚨 {t("emergency")}
      </div>

      {/* Critical Info Card */}
      <div className="card" style={{ borderColor: "rgba(255,59,59,0.3)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 800 }}>{profile.name}</div>
            <div style={{ color: "var(--muted)", fontSize: 14 }}>Age: {profile.age}</div>
          </div>
          <div className="blood-badge">{profile.bloodType}</div>
        </div>

        {/* Allergies — shown prominently */}
        {allergies.length > 0 && (
          <div className="alert alert-red">
            <div className="alert-title">⛔ {t("critical")} — ALLERGIES</div>
            {allergies.map(a => (
              <div key={a} style={{ fontFamily: "var(--font-display)", fontSize: 15, fontWeight: 700, marginBottom: 4 }}>
                ⚠️ {a}
              </div>
            ))}
          </div>
        )}

        <div className="info-row">
          <span className="info-label">Conditions</span>
          <span className="info-value">{profile.conditions || "None recorded"}</span>
        </div>
        <div className="info-row">
          <span className="info-label">Medications</span>
          <span className="info-value">{profile.medications || "None recorded"}</span>
        </div>
        <div className="info-row">
          <span className="info-label">Emergency Contact</span>
          <span className="info-value">{profile.emergencyContact || "Not provided"}</span>
        </div>
      </div>

      {/* AI Summary */}
      <div className="card">
        <div className="card-title">🤖 {t("aiSummary")}</div>
        {generatingAI ? (
          <div className="loading-spinner">
            <div className="spinner" />
            {t("generating")}
          </div>
        ) : (
          <>
            <div className="ai-output">{aiSummary}</div>
            <button
              className="btn-icon"
              style={{ marginTop: 12, width: "100%", justifyContent: "center" }}
              onClick={() => generateSummary(profile)}
            >
              🔄 Regenerate Summary
            </button>
          </>
        )}
      </div>

      {/* Full Records — OTP Protected */}
      <div className="card">
        <div className="card-title">🔒 Full Medical Records</div>
        {!showFull ? (
          <div>
            <div className="alert alert-amber">
              <div className="alert-title">⚠️ OTP Required</div>
              <p style={{ fontSize: 13 }}>Full records require patient consent via OTP sent to their registered phone.</p>
            </div>
            {!otpSent ? (
              <button className="btn-secondary" onClick={handleSendOTP}>
                📱 {t("sendOTP")} to Patient
              </button>
            ) : (
              <div>
                <div className="input-group" style={{ marginTop: 16 }}>
                  <label className="input-label">{t("otpPrompt")}</label>
                  <input
                    className="otp-input"
                    value={otpInput}
                    onChange={e => setOtpInput(e.target.value)}
                    maxLength={6}
                    placeholder="000000"
                  />
                </div>
                {otpError && <p style={{ color: "var(--red)", fontSize: 13, marginBottom: 12 }}>{otpError}</p>}
                <button className="btn-primary" onClick={handleVerifyOTP}>
                  ✓ {t("verifyOTP")}
                </button>
              </div>
            )}
          </div>
        ) : (
          <div>
            <div className="alert alert-green">
              <div className="alert-title">✓ Access Granted</div>
              <p style={{ fontSize: 13 }}>Patient verified. Full records visible.</p>
            </div>
            {[
              ["Full Name", profile.name],
              ["Age", profile.age],
              ["Blood Type", profile.bloodType],
              ["All Allergies", profile.allergies],
              ["Medical Conditions", profile.conditions],
              ["Current Medications", profile.medications],
              ["Emergency Contact", profile.emergencyContact],
            ].map(([label, value]) => (
              <div className="info-row" key={label}>
                <span className="info-label">{label}</span>
                <span className="info-value">{value || "—"}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
