// src/components/MyQR.js
import React, { useEffect, useRef, useState } from "react";
import QRCode from "qrcode";

export default function MyQR({ userId, onDrugCheck }) {
  const canvasRef = useRef(null);
  const [copied, setCopied] = useState(false);

  const scanUrl = `${window.location.origin}?scan=${userId}`;

  useEffect(() => {
    if (canvasRef.current) {
      QRCode.toCanvas(canvasRef.current, scanUrl, {
        width: 220, margin: 2,
        color: { dark: "#000000", light: "#ffffff" }
      });
    }
  }, [scanUrl]);

  const copyLink = () => {
    navigator.clipboard.writeText(scanUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div>
      <div className="card" style={{ textAlign: "center" }}>
        <div className="card-title" style={{ textAlign: "center" }}>Your Emergency QR Code</div>

        <div className="emergency-badge" style={{ margin: "0 auto 20px" }}>
          🚨 Show this to any doctor in an emergency
        </div>

        <div className="qr-wrap">
          <canvas ref={canvasRef} />
          <p>PULSE ID — Scan for Emergency Medical Summary</p>
        </div>

        <p style={{ fontSize: 13, color: "var(--muted)", marginBottom: 20, lineHeight: 1.6 }}>
          This QR gives doctors instant access to your critical medical info — blood type, allergies, conditions. No app needed to scan.
        </p>

        <button className="btn-primary" onClick={copyLink} style={{ marginBottom: 12 }}>
          {copied ? "✓ Copied!" : "🔗 Copy Emergency Link"}
        </button>

        <button className="btn-secondary" onClick={onDrugCheck}>
          💊 Check Drug Interaction
        </button>
      </div>

      <div className="card">
        <div className="card-title">Privacy & Access</div>
        {[
          ["🔓 Emergency scan (anyone)", "Blood type, allergies, conditions, emergency contact"],
          ["🔒 Full records (OTP required)", "Complete history, medications, doctor notes"],
        ].map(([label, desc]) => (
          <div key={label} style={{ marginBottom: 16 }}>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{label}</div>
            <div style={{ fontSize: 13, color: "var(--muted)" }}>{desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
