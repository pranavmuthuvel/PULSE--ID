// src/components/DrugCheck.js
import React, { useState, useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import { getProfileById } from "../services/firebaseService";
import { checkDrugInteraction } from "../services/claudeService";

export default function DrugCheck({ userId, lang, onBack }) {
  const { t } = useTranslation();
  const [profile, setProfile] = useState(null);
  const [drugInput, setDrugInput] = useState("");
  const [result, setResult] = useState("");
  const [checking, setChecking] = useState(false);
  const [listening, setListening] = useState(false);
  const [history, setHistory] = useState([]);
  const recRef = useRef(null);

  const langCodeMap = { en: "en-IN", ta: "ta-IN", hi: "hi-IN", bn: "bn-IN" };

  useEffect(() => {
    if (userId) {
      getProfileById(userId).then(p => { if (p) setProfile(p); });
    }
  }, [userId]);

  const startVoice = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { alert("Voice not supported. Use Chrome."); return; }
    const rec = new SpeechRecognition();
    rec.lang = langCodeMap[lang] || "en-IN";
    rec.onstart = () => setListening(true);
    rec.onend = () => setListening(false);
    rec.onresult = (e) => setDrugInput(e.results[0][0].transcript);
    rec.start();
    recRef.current = rec;
  };

  const handleCheck = async () => {
    if (!drugInput.trim()) return;
    setChecking(true);
    setResult("");
    try {
      const mockProfile = profile || {
        medications: "Amlodipine 5mg, Salbutamol 100mcg",
        conditions: "Hypertension, Asthma"
      };
      const res = await checkDrugInteraction(mockProfile, drugInput, lang);
      setResult(res);
      setHistory(prev => [{ drug: drugInput, result: res, time: new Date().toLocaleTimeString() }, ...prev.slice(0, 4)]);
    } catch (e) {
      setResult("Error checking interaction. Please verify your API key.");
    }
    setChecking(false);
  };

  const getStatusColor = (text) => {
    const lower = text.toLowerCase();
    if (lower.includes("dangerous") || lower.includes("⛔")) return "red";
    if (lower.includes("warning") || lower.includes("caution") || lower.includes("⚠️")) return "amber";
    return "green";
  };

  return (
    <div>
      <button className="back-btn" onClick={onBack}>← Back</button>

      <div className="card">
        <div className="card-title">💊 {t("drugCheck")}</div>

        {profile && (
          <div className="alert alert-cyan" style={{ marginBottom: 16 }}>
            <div className="alert-title">Patient Context Loaded</div>
            <p style={{ fontSize: 13 }}>
              <strong>{profile.name}</strong> — Current meds: {profile.medications || "None"}<br />
              Conditions: {profile.conditions || "None"}
            </p>
          </div>
        )}

        {!profile && (
          <div className="alert alert-amber" style={{ marginBottom: 16 }}>
            <div className="alert-title">No Patient Profile Loaded</div>
            <p style={{ fontSize: 13 }}>Checking against demo profile. Scan patient QR for accurate results.</p>
          </div>
        )}

        <div className="input-group">
          <label className="input-label">{t("drugInput")}</label>
          <div className="input-with-voice">
            <input
              className="input-field"
              value={drugInput}
              onChange={e => setDrugInput(e.target.value)}
              placeholder="e.g. Ibuprofen, Metformin..."
              onKeyDown={e => e.key === "Enter" && handleCheck()}
            />
            <button className={`btn-icon ${listening ? "listening" : ""}`} onClick={startVoice}>
              🎤 {listening ? t("listening") : t("speak")}
            </button>
          </div>
        </div>

        <button className="btn-primary" onClick={handleCheck} disabled={checking || !drugInput.trim()}>
          {checking ? `⏳ ${t("checking")}` : `🔍 ${t("check")}`}
        </button>
      </div>

      {result && (
        <div className="card">
          <div className="card-title">Interaction Analysis — {drugInput}</div>
          <div className={`alert alert-${getStatusColor(result)}`}>
            <div className="alert-title">
              {getStatusColor(result) === "red" && "⛔ DANGEROUS INTERACTION"}
              {getStatusColor(result) === "amber" && "⚠️ CAUTION — INTERACTION DETECTED"}
              {getStatusColor(result) === "green" && "✓ SAFE TO PRESCRIBE"}
            </div>
          </div>
          <div className="ai-output">{result}</div>
        </div>
      )}

      {history.length > 0 && (
        <div className="card">
          <div className="card-title">Check History</div>
          {history.map((h, i) => (
            <div key={i} style={{
              padding: "12px 0",
              borderBottom: i < history.length - 1 ? "1px solid var(--border)" : "none"
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontFamily: "var(--font-display)", fontSize: 13, fontWeight: 700 }}>{h.drug}</span>
                <span style={{ fontSize: 11, color: "var(--muted)" }}>{h.time}</span>
              </div>
              <div style={{ fontSize: 12, color: "var(--muted)", lineHeight: 1.4 }}>
                {h.result.substring(0, 100)}...
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
