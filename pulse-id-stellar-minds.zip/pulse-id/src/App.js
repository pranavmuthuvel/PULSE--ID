// src/App.js
import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import "./i18n";
import ProfileBuilder from "./components/ProfileBuilder";
import MyQR from "./components/MyQR";
import EmergencyScan from "./components/EmergencyScan";
import DrugCheck from "./components/DrugCheck";
import LandingPage from "./components/LandingPage";
import LanguageSelector from "./components/LanguageSelector";
import "./App.css";

export default function App() {
  const { t, i18n } = useTranslation();
  const [screen, setScreen] = useState("landing");
  const [userId, setUserId] = useState(null);
  const [profile, setProfile] = useState(null);
  const [lang, setLang] = useState("en");

  // Check URL for QR scan
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const scanId = params.get("scan");
    if (scanId) {
      setUserId(scanId);
      setScreen("emergency");
    }
    const savedId = localStorage.getItem("pulseUserId");
    if (savedId && !scanId) setUserId(savedId);
  }, []);

  const changeLanguage = (l) => {
    setLang(l);
    i18n.changeLanguage(l);
  };

  const nav = (s) => setScreen(s);

  return (
    <div className="app-root">
      <header className="app-header">
        <div className="header-left" onClick={() => nav("landing")} style={{ cursor: "pointer" }}>
          <span className="pulse-dot" />
          <span className="app-title">{t("appName")}</span>
        </div>
        <div className="header-right">
          <LanguageSelector lang={lang} onChange={changeLanguage} />
          {userId && (
            <button className="btn-ghost" onClick={() => { localStorage.removeItem("pulseUserId"); setUserId(null); nav("landing"); }}>
              {t("logout")}
            </button>
          )}
        </div>
      </header>

      <main className="app-main">
        {screen === "landing" && (
          <LandingPage
            userId={userId}
            onCreateProfile={() => nav("profile")}
            onMyQR={() => nav("qr")}
            onScan={() => nav("emergency")}
            onDrugCheck={() => nav("drug")}
          />
        )}
        {screen === "profile" && (
          <ProfileBuilder
            userId={userId}
            lang={lang}
            onSaved={(id, p) => { setUserId(id); setProfile(p); localStorage.setItem("pulseUserId", id); nav("qr"); }}
          />
        )}
        {screen === "qr" && userId && (
          <MyQR userId={userId} onDrugCheck={() => nav("drug")} />
        )}
        {screen === "emergency" && (
          <EmergencyScan userId={userId} lang={lang} onBack={() => nav("landing")} />
        )}
        {screen === "drug" && (
          <DrugCheck userId={userId} lang={lang} onBack={() => nav("landing")} />
        )}
      </main>
    </div>
  );
}
