// src/services/firebaseService.js
import { db } from "../firebase";
import {
  doc, setDoc, getDoc, collection, addDoc, serverTimestamp
} from "firebase/firestore";

// Save patient profile
export async function saveProfile(userId, profileData) {
  const profileRef = doc(db, "profiles", userId);
  await setDoc(profileRef, {
    ...profileData,
    updatedAt: serverTimestamp(),
    userId
  });
  return userId;
}

// Get profile by userId (QR scan)
export async function getProfileById(userId) {
  const profileRef = doc(db, "profiles", userId);
  const snap = await getDoc(profileRef);
  if (snap.exists()) return snap.data();
  return null;
}

// Log emergency access (audit trail)
export async function logEmergencyAccess(profileId, accessType) {
  await addDoc(collection(db, "accessLogs"), {
    profileId,
    accessType,
    timestamp: serverTimestamp(),
    userAgent: navigator.userAgent
  });
}

// Generate simple OTP (in production use Firebase Phone Auth)
export function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}
