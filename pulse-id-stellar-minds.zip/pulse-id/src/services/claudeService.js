// src/services/claudeService.js
// Replace CLAUDE_API_KEY with your actual key from console.anthropic.com

const CLAUDE_API_KEY = "YOUR_CLAUDE_API_KEY";
const CLAUDE_MODEL = "claude-sonnet-4-20250514";

export async function generateEmergencySummary(profile, language = "en") {
  const langMap = { en: "English", ta: "Tamil", hi: "Hindi", bn: "Bengali" };
  const langName = langMap[language] || "English";

  const prompt = `You are an emergency medical AI assistant. Generate a structured emergency medical summary for a paramedic or ER doctor. Be concise, prioritize life-threatening information first.

Patient Data:
- Name: ${profile.name}, Age: ${profile.age}
- Blood Type: ${profile.bloodType}
- Allergies: ${profile.allergies}
- Medical Conditions: ${profile.conditions}
- Current Medications: ${profile.medications}
- Emergency Contact: ${profile.emergencyContact}

Generate the summary in ${langName}. Format it as:
1. CRITICAL FLAGS (allergies that could cause immediate death, life-threatening conditions)
2. Active Conditions
3. Current Medications  
4. AI Clinical Warning (what to avoid, what risks exist)
5. Recommended nearest hospital type needed

Be direct, clinical, and prioritize what could kill this patient in the next 10 minutes. Always end with "Confirm with licensed physician before administering treatment."`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": CLAUDE_API_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify({
      model: CLAUDE_MODEL,
      max_tokens: 1000,
      messages: [{ role: "user", content: prompt }]
    })
  });

  const data = await response.json();
  return data.content[0].text;
}

export async function checkDrugInteraction(profile, newDrug, language = "en") {
  const langMap = { en: "English", ta: "Tamil", hi: "Hindi", bn: "Bengali" };
  const langName = langMap[language] || "English";

  const prompt = `You are a clinical pharmacology AI. Check for drug interactions.

Patient's current medications: ${profile.medications}
Patient's conditions: ${profile.conditions}
New drug being considered: ${newDrug}

Respond in ${langName} with:
1. INTERACTION STATUS: Safe / Warning / Dangerous
2. Specific interaction details if any
3. Clinical reasoning (why this interaction occurs)
4. Safer alternative if dangerous
5. Recommendation

Be concise and clinical. Always end with "Consult prescribing physician."`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": CLAUDE_API_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify({
      model: CLAUDE_MODEL,
      max_tokens: 600,
      messages: [{ role: "user", content: prompt }]
    })
  });

  const data = await response.json();
  return data.content[0].text;
}

export async function transcribeAndExtract(spokenText, language = "en") {
  const prompt = `Extract medical profile information from this spoken text and return as JSON only (no markdown):
  
Spoken text: "${spokenText}"

Return JSON with these fields (use empty string if not mentioned):
{
  "name": "",
  "age": "",
  "bloodType": "",
  "allergies": "",
  "conditions": "",
  "medications": "",
  "emergencyContact": ""
}`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": CLAUDE_API_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify({
      model: CLAUDE_MODEL,
      max_tokens: 400,
      messages: [{ role: "user", content: prompt }]
    })
  });

  const data = await response.json();
  try {
    return JSON.parse(data.content[0].text);
  } catch {
    return null;
  }
}
